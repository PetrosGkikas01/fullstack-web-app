const db = require("../config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  const { name, email, password, specialty, is_admin } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    await db.query(
      "INSERT INTO Professor (name, email, password, specialty, is_admin) VALUES (?, ?, ?, ?, ?)",
      [name, email, hashedPassword, specialty || "", is_admin || false]
    );
    res.status(201).json({ message: "Professor registered successfully!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const [results] = await db.query("SELECT * FROM Professor WHERE email = ?", [email]);

    if (results.length === 0)
      return res.status(401).json({ error: "Invalid credentials" });

    const match = await bcrypt.compare(password, results[0].password);
    if (!match)
      return res.status(401).json({ error: "Invalid credentials" });

    const token = jwt.sign(
      { id: results[0].id, role: "professor" },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
exports.createTopic = (req, res) => {
  const { title, description } = req.body;
  const professor_id = req.user.id;
  const pdf_file = req.file ? req.file.filename : null;

  const sql =
    "INSERT INTO DiplomatikhErgasia (title, description, professor_id, status, pdf_file) VALUES (?, ?, ?, 'available', ?)";

  db.query(sql, [title, description, professor_id, pdf_file], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ message: "Το θέμα δημιουργήθηκε επιτυχώς." });
  });
};


exports.getMyTopics = (req, res) => {
 console.log("Decoded user from token:", req.user);
  const professor_id = req.user.id;

  const sql = 
    "SELECT id, title, description, status, pdf_file FROM DiplomatikhErgasia WHERE professor_id = ? ORDER BY id DESC";

  db.query(sql, [professor_id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    console.log("Topics found:", results);
    res.json(results);
  });
};